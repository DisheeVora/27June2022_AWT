function my(){
    document.getElementById("awt").style.fontFamily = "forte";
   
}

function me(){
document.getElementById("awt").style.fontSize = "100px";
}

function ms(){
    document.getElementById("awt").style.display ="none";

    }

